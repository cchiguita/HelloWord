
export class Helpers {
    static readonly WISHLIST_TEXT = " Edit your account information";
}
