export class HomePage {
    static readonly WISHLIST = "//a[normalize-space()='Edit your account information']";
}